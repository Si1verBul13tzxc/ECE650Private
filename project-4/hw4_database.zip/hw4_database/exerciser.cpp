#include "exerciser.h"

void exercise(connection * C) {
  query5(C, 13);
}
